
# Module-5 Coding Assignment

Coursera course: HTML, CSS, and Javascript for Web Developers

# To see the output [CLICK HERE](https://siddartha19.github.io/Coursera-HTML-CSS-and-JavaScript-for-Web-Developers/Assignments/module-5/index.html)
